package pwmng;

public class AMGeneral {  
     double[] compPwrApps= new double[256];
     double[] SlaApps= new double[256];
     public int [] recForCoop;
 
    public void monitor()
    {   
    }
    public void analysis(Object vilation)
    {
        
    }
    public void planning()
    {
    }
    public void execution()
    {
    }
}
