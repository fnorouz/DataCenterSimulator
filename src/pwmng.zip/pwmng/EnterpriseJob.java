package pwmng;
public class EnterpriseJob extends Job{
    double numberOfJob;
    int arrivalTimeOfJob;
    EnterpriseJob()
    {
        numberOfJob=0;
        arrivalTimeOfJob=0;
    }
}
