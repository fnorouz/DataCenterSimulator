/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pwmng;

public class AMComputeSys extends AMGeneral{
   ComputeSystem CS;
   int SLAvil=0;
   Main.strategyEnum strtg;
  public AMComputeSys(ComputeSystem cs)
   {
       CS=cs;
   }
   @Override
   public void monitor()
    {
        SLAcal(); //calculate SLA violation of itself
        getPercentageOfComputingPwr();
  
    }
   public double getPercentageOfComputingPwr(){
       double percnt=0; 
       int []levels= {0,0,0};
        int index=0;
        for(int j=0;j<CS.ComputeNodeList.size();j++)
        {
            if(CS.ComputeNodeList.get(j).ready!=-1) //it is idle             
            {
                index=CS.ComputeNodeList.get(j).getCurrentFreqLevel();
                levels[index]++;
            }
        }
        percnt=percnt + levels[0]+2*levels[1]+3*levels[2];
        return percnt;
    }
   public void SLAcal(){
        if(CS.SLAViolationType!=violation.NOTHING)
            SLAvil++;
    }
   @Override
    public void planning()
    {
        if(strtg==Main.strategyEnum.Green)
        {
            for(int i=0;i<CS.ComputeNodeList.size();i++)
            {
                if(CS.ComputeNodeList.get(i).activeBatchList.isEmpty() && CS.ComputeNodeList.get(i).blockedBatchList.isEmpty())
                {
                    CS.ComputeNodeList.get(i).ready=-3;    
                }
                if(CS.ComputeNodeList.get(i).ready==1)
                                   CS.ComputeNodeList.get(i).decreaseFrequency();
                
             }
        }
    }
   @Override
    public void execution()
    {
        
    }
   @Override
   public void analysis(Object vilation)
    {
        if(Main.localTime%Main.epochApp!=0)
            return;
        int avgVilation=SLAvil/Main.epochApp;
        SLAvil=0;
        if(avgVilation==0)
        {
            strtg=Main.strategyEnum.Green; 
        }
        else {
            strtg=Main.strategyEnum.SLA; 
            
        } 
    }
}

