package pwmng;

public class AMDataCenter extends AMGeneral{  
    int [] sysSLAviolation;
    
    @Override
    public void monitor()
    {   
        
        
    }
    @Override
    public void analysis(Object vilation)
    {
        
    }
    @Override
    public void planning()
    {
        
    }
    @Override
    public void execution()
    {
        
    }
}
