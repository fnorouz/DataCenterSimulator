package pwmng;

import java.util.ArrayList;

public class Scheduler {
    public Scheduler()
    {
    }
    
    public Job nextJob(ArrayList<? extends Job> s)
    {
         return null;
    }

    /*int whichServer()
       {
           int i=0, j=0;
           for(i=0;i<powIndex.length;i++)
           {
              for(j=0;j<serverList.size();j++)
                   if(serverList.get(j).ready==1 && powIndex[i]==serverList.get(j).chassisID)
                      return j;
           }
           return -2;
       }*/
   
}
