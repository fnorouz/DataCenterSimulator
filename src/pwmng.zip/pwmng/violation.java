package pwmng;
public enum violation {
    NOTHING, ComputeNodeShortage, DEADLINEPASSED
    }