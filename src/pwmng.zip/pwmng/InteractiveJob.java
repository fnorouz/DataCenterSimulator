package pwmng;
public class InteractiveJob extends Job{
    double numberOfJob;
    int arrivalTimeOfJob;
    InteractiveJob()
    {
        arrivalTimeOfJob=0;
        numberOfJob=0;
    }
}
